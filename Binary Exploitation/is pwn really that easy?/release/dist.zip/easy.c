#include <stdio.h>
#include <signal.h>

void init()
{
    setvbuf(stdin, NULL, _IONBF, 0);
    setvbuf(stdout, NULL, _IONBF, 0);
    setvbuf(stderr, NULL, _IONBF, 0);
}

void win()
{
    FILE *fp = fopen("/flag.txt", "r");
    char flag[256];
    fgets(flag, sizeof(flag), fp);
    printf("Flag: %s\n", flag);
    fclose(fp);
}

int main()
{
    init();
    char buffer[0x10];
    printf("input something here: ");
    gets(buffer);
    return 0;
}