from flask import Flask, request
app = Flask(__name__)

@app.get("/hello")
def hello():
    return {"msg": "akmwflag"}

@app.post("/echo")
def echo():
    return {"sent": request.get_json()}

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=True)
