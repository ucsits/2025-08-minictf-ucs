#include <stdio.h>
#include <signal.h>

void init()
{
    setvbuf(stdin, 0, 2, 0);
    setvbuf(stdout, 0, 2, 0);
    setvbuf(stderr, 0, 2, 0);
}

void signal_handler()
{
    FILE *fp = fopen("/flag.txt", "r");
    char flag[1000];
    fgets(flag, sizeof(flag), fp);
    printf("Flag: %s\n", flag);
    fclose(fp);
}

int main()
{
    init();
    signal(SIGSEGV, signal_handler);
    char buffer[0x800];
    printf("input something here: ");
    gets(buffer);
    return 0;
}